# Studio Master IA 🎛️

Application web de **mastering audio intelligent** : vous importez un titre,
le moteur analyse le signal (loudness ITU-R BS.1770, spectre STFT, dynamique,
stéréo) et applique une chaîne de traitement **adaptative** selon le style
choisi, puis vous écoutez avant/après en A/B et téléchargez le master.

100 % local — aucun fichier ne quitte votre machine.

## Lancer

```bash
python3 server.py
# → http://localhost:8000
```

Dépendances : `numpy`, `scipy`, `soundfile`, `lameenc` (encodage MP3).
Formats d'entrée : WAV, MP3, FLAC, OGG (via libsndfile). Max 80 Mo / 1 h.

## Comment ça marche

1. **Analyse** — loudness intégrée (pondération K, gate −10 LU), pics, RMS,
   dynamique (percentiles 1 s), largeur stéréo, énergie par bande (20 Hz–16 kHz),
   détection de clipping et de dérive DC.
2. **Décision** — chaque profil définit une cible LUFS, un plafond, des
   références spectrales et des paramètres de compression. Le moteur corrige
   uniquement les écarts mesurés (EQ), compresse seulement si le matériau est
   assez dynamique, et plafonne le gain final sur les pics.
3. **Chaîne de traitement** :

   | Étape | Détail |
   |---|---|
   | DC block | retire la dérive si détectée |
   | Trim d'entrée | normalise le niveau avant compression (± 0.5 dB max ±12/+8) |
   | EQ adaptatif | shelves 75 Hz / 9 kHz, peaking 160 / 380 / 1000 / 3500 Hz, gain limité au profil |
   | Compression | blocs ~45 ms, ratio 1.5–3.2, attaque 12–25 ms, relâche 150–300 ms |
   | Support | vinyle : HPF 50 Hz + mono < 100 Hz ; club : mono < 60 Hz |
   | Niveau final | cible LUFS du profil, plafonné par le plafond − 0.5 dB |
   | Limiteur | à anticipation (~4 ms), plafond −0.8…−1.5 dB selon le profil |

## Profils

| Profil | Cible | Plafond | Usage |
|---|---|---|---|
| Streaming | −14 LUFS | −1.0 dB | Spotify, Apple Music, YouTube |
| Radio / CD | −16 LUFS | −1.0 dB | Diffusion, broadcast |
| Vinyle | −14 LUFS | −1.5 dB | Pressage (graves restreints) |
| Club / EDM | −11 LUFS | −0.8 dB | Soirées, mobile |
| Léger (naturel) | −14 LUFS | −1.5 dB | Acoustique, pré-pro |

## API

| Route | Méthode | Rôle |
|---|---|---|
| `/api/analyze` | POST multipart `file` | Analyse, renvoie job_id + métriques |
| `/api/demo` | POST | Génère une démo et la retourne analysée |
| `/api/master` | POST form `job_id`, `profile` | Masterise, renvoie avant/après + étapes |
| `/api/profiles` | GET | Liste des profils |
| `/api/result/{job}/{name}` | GET | Récupère `original.wav`, `{profile}.wav` (24 bit), `{profile}.mp3` (192 k) |

Les sessions (fichiers en mémoire) expirent après 30 min.

## Arborescence

```
mastering-app/
├── server.py              # serveur aiohttp
├── mastering/
│   ├── analysis.py        # LUFS BS.1770, STFT, dynamique, stéréo
│   ├── chain.py           # chaîne adaptative (décision + traitement)
│   ├── dsp.py             # EQ biquad, DC, compresseur, limiteur
│   ├── profiles.py        # profils de mastering
│   └── demo.py            # générateur de démo
└── static/
    ├── index.html
    ├── style.css
    └── app.js             # UI : upload, analyse, A/B (Web Audio), onde
```

## Limites connues

- Le plafond est garanti à l'échantillon (pas true-peak suréchantillonné).
- Le mastering est DSP adaptatif (pas de réseau de neurones) : il est
  déterministe, rapide et transparent, mais ne « réinvente » pas le mix.
- Les fichiers > 1 h ou > 80 Mo sont refusés.
