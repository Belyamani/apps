"""Analyse du signal : LUFS (ITU-R BS.1770), spectre STFT, dynamique, stéréo."""
import math

import numpy as np
from scipy.signal import resample_poly, stft

def _k_design():
    """Pondération K ITU-R BS.1770 @ 48 kHz.

    Stade 1 : passe-haut 4e ordre, fc = 38.1 Hz (2 sections de 2e ordre).
    Stade 2 : shelf haute +4 dB, fc = 1.2 kHz.
    """
    from scipy.signal import butter
    from .dsp import biquad_shelf
    b1, a1 = butter(2, 38.1, btype="highpass", fs=48000)
    b2, a2 = biquad_shelf(48000, 1200.0, 4.0, q=0.5, high=True)
    return b1, a1, b2, a2


_KF1_B, _KF1_A, _KF2_B, _KF2_A = _k_design()

_CACHE = {}


def _cache_put(key, val):
    if len(_CACHE) > 12:
        _CACHE.clear()
    _CACHE[key] = val
    return val


def _fingerprint(x):
    """Signature faible du contenu (32 échantillons à décalage doré + énergie)
    — évite les faux positifs de cache dus au réemploi d'adresses mémoire."""
    n = x.shape[0]
    pos = sorted({min(n - 1, int(n * (k * 0.61803398875 % 1.0) + 1)) for k in range(1, 33)})
    col = x[:, 0] if x.ndim == 2 else x
    vals = tuple(round(float(col[i]), 6) for i in pos)
    energy = float(np.abs(col[:: max(1, n // 1024)]).sum())
    return vals, round(energy, 5)


def _to48k(x, sr):
    """Resampling 48 kHz pour le calcul LUFS (coefficients officiels BS.1770)."""
    if sr == 48000:
        return x
    key = ("r48", tuple(x.shape), sr, _fingerprint(x))
    hit = _CACHE.get(key)
    if hit is not None:
        return hit
    g = math.gcd(48000, int(sr))
    y = resample_poly(x, 48000 // g, int(sr) // g, axis=0)
    return _cache_put(key, y)


def _k_weight(x):
    from scipy.signal import lfilter
    y = lfilter(_KF1_B, _KF1_A, x, axis=0)
    y = lfilter(_KF1_B, _KF1_A, y, axis=0)  # 2e section du passe-haut 4e ordre
    y = lfilter(_KF2_B, _KF2_A, y, axis=0)
    return y


def _window_energy(y, frame, hop):
    """Énergie par fenêtre (somme des canaux), 1D."""
    yy = y * y
    if yy.ndim == 2:
        yy = yy.sum(axis=1)
    n = yy.shape[0]
    if n < frame:
        frame = max(n, 4800)
    nwin = max(1, (n - frame) // hop + 1)
    starts = np.arange(nwin) * hop
    s = np.cumsum(yy)
    prev = s[starts - 1].copy()
    prev[0] = 0.0
    E = s[starts + frame - 1] - prev
    return np.maximum(E, 1e-16), frame, nwin


def integrated_lufs(x, sr):
    """Loudness intégrée ITU-R BS.1770 (pondération K + gate relatif -10 LU)."""
    if not np.isfinite(x).all():
        raise ValueError("Signal non fini — calcul LUFS impossible.")
    y = _k_weight(_to48k(x, sr))
    nc = y.shape[1] if y.ndim == 2 else 1
    E, frame, nwin = _window_energy(y, 19200, 4800)  # 400 ms, overlap 75 %
    denom = frame * nc
    L_blocks = 10 * np.log10(E / denom) - 0.691
    L_ = 10 * np.log10(E.sum() / (nwin * denom)) - 0.691
    keep = L_blocks >= (L_ - 10.0)
    if not keep.any():
        return float(L_)
    return float(10 * np.log10(E[keep].sum() / (keep.sum() * denom)) - 0.691)


def short_term_lufs(x, sr, win_s=1.0):
    """Courbe de loudness à court terme (fenêtres de win_s)."""
    y = _k_weight(_to48k(x, sr))
    nc = y.shape[1] if y.ndim == 2 else 1
    frame = int(win_s * 48000)
    E, frame, _ = _window_energy(y, frame, frame // 2)
    return 10 * np.log10(E / (frame * nc)) - 0.691


def _spectrum(x, sr):
    """Spectre moyen — calculé sur un extrait de 40 s (représentatif,
    et mémoire bornée quel que soit la durée du morceau)."""
    max_n = int(40 * sr)
    if x.shape[0] > max_n:
        i0 = (x.shape[0] - max_n) // 2
        xs = x[i0: i0 + max_n]
    else:
        i0 = 0
        xs = x
    key = ("stft", i0, tuple(xs.shape), sr, _fingerprint(xs))
    hit = _CACHE.get(key)
    if hit is not None:
        return hit
    f, _, S = stft(xs, fs=sr, nperseg=4096, noverlap=3072, axis=0, window="hann")
    # S : (nfreq, nch, ntime)
    m2 = np.mean(S.real ** 2 + S.imag ** 2, axis=(1, 2))  # (nfreq,)
    return _cache_put(key, (f, m2))


def band_energies(x, sr):
    """Énergie par bande, en dB relatif à l'énergie totale."""
    f, m2 = _spectrum(x, sr)
    bands = {
        "sub": (20, 60),
        "bass": (60, 250),
        "lowmid": (250, 500),
        "mid": (500, 2000),
        "highmid": (2000, 6000),
        "air": (6000, min(16000, sr / 2 - 100)),
    }
    total = float(m2.sum()) + 1e-16
    out = {}
    for k, (lo, hi) in bands.items():
        E = float(m2[(f >= lo) & (f < hi)].sum())
        out[k] = float(10 * np.log10(E / total + 1e-12))
    return out


def spectrum_curve(x, sr, npts=40):
    """Courbe spectrale moyenne (dB relatif au max), 30 Hz → 16 kHz log."""
    f, m2 = _spectrum(x, sr)
    hi = min(16000.0, sr / 2 - 500)
    pts = np.logspace(math.log10(30), math.log10(hi), npts)
    val = np.interp(pts, f, 10 * np.log10(m2 + 1e-12))
    return (val - val.max()).tolist()


def analyze_audio(x, sr):
    if not np.isfinite(x).all():
        raise ValueError("Signal non fini (NaN/inf) — fichier corrompu ?")
    n, nch = x.shape
    lufs = integrated_lufs(x, sr)
    peak = float(np.max(np.abs(x)))
    peak_db = 20 * math.log10(max(peak, 1e-9))
    rms = float(np.sqrt(np.mean(x ** 2)))
    rms_db = 20 * math.log10(max(rms, 1e-9))

    st = short_term_lufs(x, sr, 1.0)
    valid = st[st > -50.0]
    dr = float(np.percentile(valid, 95) - np.percentile(valid, 5)) if valid.size > 2 else 0.0

    width = 0.0
    if nch == 2:
        L, R = x[:, 0], x[:, 1]
        d = float(np.dot(L, R) / (np.sqrt(np.dot(L, L)) * np.sqrt(np.dot(R, R)) + 1e-12))
        width = (1.0 - max(-1.0, min(1.0, d))) / 2.0 * 100.0

    return {
        "duration_s": round(n / sr, 2),
        "sample_rate": int(sr),
        "channels": int(nch),
        "lufs": round(lufs, 1),
        "peak_db": round(peak_db, 1),
        "rms_db": round(rms_db, 1),
        "crest": round(peak_db - lufs, 1),
        "dynamic_range": round(dr, 1),
        "width": round(width, 0),
        "bands": {k: round(v, 1) for k, v in band_energies(x, sr).items()},
        "curve": [round(v, 2) for v in spectrum_curve(x, sr)],
        "clipping": bool((np.abs(x) >= 0.9995).any()),
        "dc": bool(any(abs(float(np.mean(x[:, c]))) > 5e-4 for c in range(nch))),
    }
