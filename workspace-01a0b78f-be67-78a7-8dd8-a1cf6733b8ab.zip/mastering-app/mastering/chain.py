"""Chaîne de mastering adaptative : analyse → décision → traitement."""
import numpy as np

from .analysis import band_energies, integrated_lufs
from .dsp import (
    apply_biquad,
    biquad_highpass,
    biquad_peaking,
    biquad_shelf,
    clamp,
    compressor,
    db_to_lin,
    dc_block,
    limiter,
    mono_below,
)
from .profiles import BAND_LABEL, BAND_REASON, PROFILES

# mapping bande → filtre
_EQ = {
    "sub": lambda fs, g: biquad_shelf(fs, 75.0, g, 0.7, high=False),
    "bass": lambda fs, g: biquad_peaking(fs, 160.0, 0.9, g),
    "lowmid": lambda fs, g: biquad_peaking(fs, 380.0, 0.9, g),
    "mid": lambda fs, g: biquad_peaking(fs, 1000.0, 1.0, g),
    "highmid": lambda fs, g: biquad_peaking(fs, 3500.0, 0.8, g),
    "air": lambda fs, g: biquad_shelf(fs, 9000.0, g, 0.7, high=True),
}


def run_chain(x, sr, prof_id):
    """Applique la chaîne du profil. Returns (out, steps:list[str])."""
    p = PROFILES[prof_id]
    steps = []
    out = x.copy()

    # 1 · Dérive DC
    if any(abs(float(np.mean(out[:, c]))) > 5e-4 for c in range(out.shape[1])):
        out = dc_block(out)
        steps.append("Dérive DC détectée et supprimée")

    # 2 · Trim d'entrée (normalise le comportement du compresseur)
    src_lufs = integrated_lufs(out, sr)
    trim = clamp(p["target_lufs"] - src_lufs, -12.0, 8.0)
    if abs(trim) >= 0.5:
        out = out * db_to_lin(trim)
        steps.append(f"Trim d'entrée {trim:+.1f} dB (source à {src_lufs:.1f} LUFS)")

    # 3 · EQ adaptatif : corrige l'écart spectre mesuré / référence du profil
    #    (référence exprimée en dB relatif à la bande mid, comme le mesuré)
    spec = band_energies(out, sr)
    rel = {k: v - spec["mid"] for k, v in spec.items()}
    for band in ("sub", "bass", "lowmid", "mid", "highmid", "air"):
        diff = p["ref"][band] - rel[band]
        g = clamp(diff, -p["eq_max"], p["eq_max"])
        if abs(g) >= 0.75:
            b, a = _EQ[band](sr, g)
            out = apply_biquad(out, b, a)
            reason = BAND_REASON[band][0 if g > 0 else 1]
            steps.append(f"EQ · {BAND_LABEL[band]} : {g:+.1f} dB — {reason}")

    # 4 · Compression (seulement si le matériau est assez dynamique)
    lufs_c = integrated_lufs(out, sr)
    peak_c = 20 * np.log10(max(float(np.max(np.abs(out))), 1e-9))
    crest = peak_c - lufs_c
    c = p["comp"]
    if crest >= p["min_crest"]:
        rms_db = 20 * np.log10(max(float(np.sqrt(np.mean(out ** 2))), 1e-9))
        thr = rms_db + c["offset"]
        out, gr = compressor(
            out, sr, thr, c["ratio"], c["attack"], c["release"]
        )
        gr = float(round(gr, 1)) + 0.0
        steps.append(
            f"Compression {c['ratio']:.1f}:1 (seuil {thr:.0f} dB) — "
            f"{gr:.1f} dB de gain réduit en moyenne"
        )
    else:
        steps.append(
            "Compression omise — le matériau est déjà dense, "
            "la dynamique est préservée"
        )

    # 5 · Restrictions du support
    if p["low_cut"]:
        b, a = biquad_highpass(sr, p["low_cut"])
        out = apply_biquad(out, b, a)
        steps.append(f"Filtre passe-haut {p['low_cut']} Hz (préparation support)")
    if p["mono_low"]:
        out = mono_below(out, sr, p["mono_low"])
        steps.append(f"Mono sous {p['mono_low']} Hz (compatibilité pressage)")

    # 6 · Niveau final vers la cible LUFS (plafonné par les pics)
    lufs_now = integrated_lufs(out, sr)
    peak_now = 20 * np.log10(max(float(np.max(np.abs(out))), 1e-9))
    g_target = p["target_lufs"] - lufs_now
    g_peak = p["ceiling"] - 0.5 - peak_now
    g = min(g_target, g_peak)
    out = out * db_to_lin(g)
    steps.append(
        f"Niveau final {g:+.1f} dB → {lufs_now + g:.1f} LUFS "
        f"(cible {p['target_lufs']:.0f} LUFS)"
    )
    if g_peak < g_target - 0.3:
        steps.append("Gain plafonné par les pics — transitoires préservés")

    # 7 · Limiteur de sécurité
    out = limiter(out, sr, p["ceiling"])
    steps.append(f"Limiteur à anticipation — plafond {p['ceiling']:.1f} dB")

    if not np.isfinite(out).all():
        raise RuntimeError("Le moteur a produit un signal invalide.")
    return out, steps
