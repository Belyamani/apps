"""Génération d'une démo musicale (piano, basse, batterie, mélodie).

Le titre est volontairement « non masterisé » : niveau bas (~ -19 LUFS),
légère boue 250–500 Hz et dureté à 3.5 kHz, pour que l'effet du mastering
soit audible à l'aveugle A/B.
"""
import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100


def _tone(freq, dur, sr, harmonics, decay):
    t = np.arange(int(sr * dur)) / sr
    s = np.zeros_like(t)
    for k, amp in harmonics:
        s += amp * np.sin(2 * np.pi * freq * k * t) * np.exp(-t * decay * (1 + 0.3 * (k - 1)))
    return s


def _noise(dur, sr, rng, hp=None, decay=200.0, vol=0.2):
    t = np.arange(int(sr * dur)) / sr
    nz = rng.standard_normal(len(t))
    if hp:
        sos = butter(2, hp, btype="highpass", fs=sr, output="sos")
        nz = sosfilt(sos, nz)
    nz = nz - nz.mean()
    return nz * np.exp(-t * decay) * vol


def _delay(x, d, g=1.0):
    k = int(d * SR)
    y = np.zeros_like(x)
    if k > 0:
        y[k:] = g * x[:-k]
    return y


def make_demo(seconds=24):
    sr = SR
    n = int(sr * seconds)
    m = np.zeros(n)  # mix mono central
    rng = np.random.default_rng(7)
    bpm = 100
    beat = 60.0 / bpm

    def add(sig, t0):
        i0 = int(t0 * sr)
        i1 = min(n, i0 + len(sig))
        if i0 < n and i1 > i0:
            m[i0:i1] += sig[: i1 - i0]

    chords = [
        dict(bass=55.00, notes=[220.00, 261.63, 329.63], arp=[440.00, 523.25, 659.25, 523.25]),
        dict(bass=43.65, notes=[174.61, 220.00, 261.63], arp=[349.23, 440.00, 523.25, 440.00]),
        dict(bass=65.41, notes=[261.63, 329.63, 392.00], arp=[523.25, 659.25, 783.99, 659.25]),
        dict(bass=49.00, notes=[196.00, 246.94, 293.66], arp=[392.00, 493.88, 587.33, 493.88]),
    ]
    melody_notes = [440.00, 523.25, 587.33, 659.25, 783.99, 880.00]
    melody_seq = [0, 2, 3, 2, 4, 3, 2, 3, 0, 2, 3, 4, 5, 4, 3, 2]

    nbeats = int(seconds / beat)
    nbar = nbeats // 4
    for bar in range(nbar):
        ch = chords[bar % 4]
        t_bar = bar * 4 * beat
        # Structure : intro (mesure 1), montée (2), full (3-8), breakdown (9), final (10)
        has_pads = bar >= 0
        has_piano = bar >= 0
        has_bass = bar >= 1
        has_drums = (2 <= bar <= 7) or bar == 9
        has_melody = bar >= 1 and bar != 8

        # Pad : accord soutenu
        if has_pads:
            vol = 0.11 if bar in (0, 8) else 0.13
            tp = np.arange(int(sr * 4 * beat)) / sr
            env = np.clip(tp / (0.3 * beat), 0.0, 1.0) * (0.5 + 0.5 * np.cos(np.pi * tp / (4 * beat)))
            for f in ch["notes"]:
                add((np.sin(2 * np.pi * f * tp)
                     + 0.3 * np.sin(2 * np.pi * f * 2 * tp)
                     + 0.12 * np.sin(2 * np.pi * f * 4 * tp)) * env * vol, t_bar)

        # Piano : accord posé (temps 1) + arpège (temps 2-4)
        if has_piano:
            for f in ch["notes"]:
                add(_tone(f, 2.0 * beat, sr, [(1, 1.0), (2, 0.4), (3, 0.18), (4, 0.08)], 1.4) * 0.26, t_bar)
            for i, f in enumerate(ch["arp"]):
                add(_tone(f, 0.9 * beat, sr, [(1, 1.0), (2, 0.35), (3, 0.12)], 4.0) * 0.16,
                    t_bar + (1 + i * 0.5) * beat)

        # Basse : croches sur la note de l'accord
        if has_bass:
            for i in range(8):
                add(_tone(ch["bass"], 0.5 * beat, sr, [(1, 1.0), (2, 0.35)], 1.1) * 0.14,
                    t_bar + i * 0.5 * beat)

        # Batterie : kick 1 & 3, caisse 2 & 4, charleys en croches
        if has_drums:
            for bt in (0, 2):
                tk = np.arange(int(sr * 0.25)) / sr
                f = 110 * np.exp(-tk * 22) + 42
                ph = 2 * np.pi * np.cumsum(f) / sr
                k = np.sin(ph) * np.exp(-tk * 18)
                k = k + _noise(0.25, sr, rng) * 0.25 * np.exp(-tk * 400)
                add(k * 0.22, t_bar + bt * beat)
            for bt in (1, 3):
                tb = np.arange(int(sr * 0.18)) / sr
                body = np.sin(2 * np.pi * 180 * tb) * np.exp(-tb * 60) * 0.3
                add(_noise(0.18, sr, rng, hp=1500, decay=30, vol=0.26) + body, t_bar + bt * beat)
            for i in range(8):
                open_hat = (i % 2 == 1)
                add(_noise(0.12 if open_hat else 0.04, sr, rng, hp=7000,
                           decay=60 if open_hat else 220, vol=0.26),
                    t_bar + i * 0.5 * beat)
                add(_noise(0.28, sr, rng, hp=5000, decay=14, vol=0.04),
                    t_bar + i * 0.5 * beat)  # ride : air 6-14 kHz

        # Mélodie (à partir de la 2e mesure), avec écho + shimmer aigu
        if has_melody:
            for i in range(8):
                f = melody_notes[melody_seq[(bar * 8 + i) % 16]]
                pl = _tone(f, 0.8 * beat, sr,
                           [(1, 1.0), (2, 0.5), (3, 0.33), (4, 0.25), (5, 0.2), (6, 0.12), (7, 0.08), (8, 0.05)], 2.8) * 0.30
                t0 = t_bar + i * 0.5 * beat
                add(pl, t0)
                add(pl * 0.35, t0 + 0.375)
                sh = np.sin(2 * np.pi * f * 8 * np.arange(int(sr * 0.6)) / sr) * np.exp(
                    -np.arange(int(sr * 0.6)) / sr * 1.8) * 0.06
                add(sh, t0)

    # Stéréo : Haas asymétrique + petite salle mono
    L = 0.85 * m + 0.30 * _delay(m, 0.012)
    R = 0.85 * m + 0.30 * _delay(m, 0.023)
    room = 0.16 * _delay(m, 0.023) + 0.11 * _delay(m, 0.037) + 0.07 * _delay(m, 0.055)
    L = L + room
    R = R + room

    # Caractère « non masterisé » (léger) : boue 350 Hz + dureté 3.5 kHz
    for name, f0, q, g in (("mud", 350.0, 1.0, 2.5), ("harsh", 3500.0, 1.2, 1.8)):
        from .dsp import biquad_peaking, apply_biquad
        b, a = biquad_peaking(sr, f0, q, g)
        L, R = apply_biquad(L, b, a), apply_biquad(R, b, a)

    # Niveau cible d'un pre-master : ~ -19 LUFS avec une crête réaliste
    # (~ 10 dB) : un soft-clip tanh resserre les transitoires avant la
    # normalisation, comme le ferait un compresseur de bus en mix.
    from .analysis import integrated_lufs
    x = np.stack([L, R], axis=1)
    peak = np.max(np.abs(x))
    x = x / max(peak, 1e-9) * (10 ** (-8 / 20))
    x = np.tanh(x / 0.18) * 0.18  # glue : crête ~ 10 dB
    cur = integrated_lufs(x, sr)
    x = x * (10 ** ((-19.0 - cur) / 20))
    return x, sr
