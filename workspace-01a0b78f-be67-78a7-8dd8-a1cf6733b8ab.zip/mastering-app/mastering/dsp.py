"""Briques DSP : EQ biquad, blocage DC, compression, limiteur."""
import math

import numpy as np
from scipy.signal import lfilter
from scipy.ndimage import maximum_filter1d


def db_to_lin(db):
    return 10.0 ** (db / 20.0)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _norm(b, a):
    return b / a[0], a / a[0]


# ---------------------------------------------------------------- EQ biquad
# Formules exactes du « Audio EQ Cookbook » (Rob Bristow-Johnson).
# A = 10^(dB/40) — racine du ratio d'amplitude.

def biquad_peaking(fs, f0, q, gain_db):
    """Peaking : H(s) = (s² + s·A/Q + 1) / (s² + s/(A·Q) + 1)."""
    w0 = 2 * math.pi * f0 / fs
    c = math.cos(w0)
    A = 10.0 ** (gain_db / 40.0)
    alpha = math.sin(w0) / (2 * q)
    b = np.array([1 + alpha * A, -2.0 * c, 1 - alpha * A])
    a = np.array([1 + alpha / A, -2.0 * c, 1 - alpha / A])
    return _norm(b, a)


def biquad_shelf(fs, f0, gain_db, q=0.7071, high=True):
    """Shelf low/high selon le cookbook RBJ (A = 10^(dB/40))."""
    w0 = 2 * math.pi * f0 / fs
    c = math.cos(w0)
    A = 10.0 ** (gain_db / 40.0)
    sA = math.sqrt(A)
    alpha = math.sin(w0) / (2 * q)
    if high:
        # H(s) = A·(A·s² + (√A/Q)·s + 1) / (s² + (√A/Q)·s + A)
        b = np.array([A * ((A + 1) + (A - 1) * c + 2 * sA * alpha),
                      -2 * A * ((A - 1) + (A + 1) * c),
                      A * ((A + 1) + (A - 1) * c - 2 * sA * alpha)])
        a = np.array([(A + 1) - (A - 1) * c + 2 * sA * alpha,
                      2 * ((A - 1) - (A + 1) * c),
                      (A + 1) - (A - 1) * c - 2 * sA * alpha])
    else:
        # H(s) = A·(s² + (√A/Q)·s + A) / (A·s² + (√A/Q)·s + 1)
        b = np.array([A * ((A + 1) - (A - 1) * c + 2 * sA * alpha),
                      2 * A * ((A - 1) - (A + 1) * c),
                      A * ((A + 1) - (A - 1) * c - 2 * sA * alpha)])
        a = np.array([(A + 1) + (A - 1) * c + 2 * sA * alpha,
                      -2 * ((A - 1) + (A + 1) * c),
                      (A + 1) + (A - 1) * c - 2 * sA * alpha])
    return _norm(b, a)


def biquad_highpass(fs, f0, q=0.7071):
    w0 = 2 * math.pi * f0 / fs
    cosw, sinw = math.cos(w0), math.sin(w0)
    alpha = sinw / (2 * q)
    b = np.array([(1 + cosw) / 2, -(1 + cosw), (1 + cosw) / 2])
    a = np.array([1 + alpha, -2 * cosw, 1 - alpha])
    return _norm(b, a)


def biquad_lowpass(fs, f0, q=0.7071):
    w0 = 2 * math.pi * f0 / fs
    cosw, sinw = math.cos(w0), math.sin(w0)
    alpha = sinw / (2 * q)
    b = np.array([(1 - cosw) / 2, 1 - cosw, (1 - cosw) / 2])
    a = np.array([1 + alpha, -2 * cosw, 1 - alpha])
    return _norm(b, a)


def apply_biquad(x, b, a):
    """x : (n, ch) ou (n,)."""
    if x.ndim == 1:
        return lfilter(b, a, x)
    return lfilter(b, a, x, axis=0)


def dc_block(x):
    """Retire la dérive DC : y[n] = x[n] - x[n-1] + 0.995·y[n-1]."""
    b = np.array([1.0, -1.0])
    a = np.array([1.0, -0.995])
    y = lfilter(b, a, x, axis=0)
    n = min(1024, y.shape[0])
    y[:n] = x[:n]
    return y


def mono_below(x, sr, f0, q=0.7071):
    """Mono sous f0 Hz (pratique vinyle), largeur préservée au-dessus.

    Le côté (L−R) passe en passe-haut : sous f0 les deux canaux
    reconvergent sur le milieu (mono), au-dessus le stéréo est intact.
    Le niveau du milieu n'est pas modifié.
    """
    if x.ndim == 1 or x.shape[1] != 2:
        return x
    mid = (x[:, 0] + x[:, 1]) / 2.0
    side = (x[:, 0] - x[:, 1]) / 2.0
    # passe-haut complémentaire du passe-bas (même f0, même Q) :
    # HP + LP = 1, transition propre autour de f0
    b, a = biquad_highpass(sr, f0, q)
    side_hi = lfilter(b, a, side)
    out = np.empty_like(x)
    out[:, 0] = mid + side_hi
    out[:, 1] = mid - side_hi
    return out


# ------------------------------------------------------------ Compresseur
def compressor(x, sr, threshold_db, ratio, attack_s, release_s,
               block_s=0.045, max_gr_db=20.0):
    """Compresseur de mastering à blocs (~45 ms).

    L'enveloppe (RMS stéréo) est convertie en gain cible via la courbe
    threshold/ratio, lissé entre blocs (attaque/relâche asymétriques) et
    interpolé linéairement à l'intérieur de chaque bloc → comportement
    transparent adapté au mastering.

    Returns (y, gain réduit moyen en dB).
    """
    n, nch = x.shape
    B = max(int(block_s * sr), 64)
    nb = n // B
    xb = x[: nb * B].reshape(nb, B, nch)
    env_db = 20 * np.log10(np.sqrt(np.mean(xb ** 2, axis=(1, 2))) + 1e-12)
    over = np.maximum(env_db - threshold_db, 0.0)
    target = -np.clip(over * (1.0 - 1.0 / ratio), 0.0, max_gr_db)

    a_atk = 1.0 - math.exp(-block_s / attack_s)
    a_rel = 1.0 - math.exp(-block_s / release_s)
    g = np.empty(nb)
    g[0] = target[0]
    for i in range(1, nb):
        a = a_atk if target[i] < g[i - 1] else a_rel
        g[i] = min(a * g[i - 1] + (1.0 - a) * target[i], target[i])

    t = np.linspace(0.0, 1.0, B)
    start = np.concatenate([[target[0]], g[:-1]])
    gain_db = (start[:, None] + (g - start)[:, None] * t[None, :]).ravel()
    if nb * B < n:
        gain_db = np.concatenate([gain_db, np.full(n - nb * B, g[-1])])
    gain = db_to_lin(gain_db)
    y = x * gain[:, None]
    avg_gr = float(-np.mean(gain_db))
    return y, avg_gr


# --------------------------------------------------------------- Limiteur
def limiter(x, sr, ceiling_db, block_ms=2.0, lookahead=2, release_ms=60.0):
    """Limiteur à anticipation (~4 ms), plafonnement garanti par bloc.

    Le gain appliqué à un bloc est dérivé du pic de ce bloc ET des blocs
    suivants (lookahead), lissé à la relâche — l'attaque est instantanée.
    """
    n, nch = x.shape
    B = max(int(sr * block_ms / 1000.0), 8)
    nb = n // B
    xb = x[: nb * B].reshape(nb, B, nch)
    peak = np.maximum(np.max(np.abs(xb), axis=(1, 2)), 1e-9)

    wm = maximum_filter1d(peak[::-1], size=lookahead, mode="constant", cval=0.0)[::-1]
    wm = np.maximum(wm, peak)
    target = np.minimum(1.0, db_to_lin(ceiling_db) / wm)

    a_rel = 1.0 - math.exp(-(B / sr) / (release_ms / 1000.0))
    g = np.empty(nb)
    g[0] = target[0]
    for i in range(1, nb):
        smooth = a_rel * g[i - 1] + (1.0 - a_rel) * target[i]
        g[i] = min(smooth, target[i])

    t = np.linspace(0.0, 1.0, B)
    start = np.concatenate([[g[0]], g[:-1]])
    gain = (start[:, None] + (g - start)[:, None] * t[None, :]).reshape(nb, B, 1)
    y = (xb * gain).reshape(nb * B, nch)

    tail = x[nb * B:]
    if tail.size:
        pt = max(float(np.max(np.abs(tail))), 1e-9)
        gt = min(g[-1], db_to_lin(ceiling_db) / pt)
        y = np.vstack([y, tail * gt])
    return y
