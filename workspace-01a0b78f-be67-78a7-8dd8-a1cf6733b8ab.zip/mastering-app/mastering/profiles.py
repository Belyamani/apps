"""Profils de mastering.

Chaque profil définit :
- cible de loudness (LUFS) et plafond (dB)
- paramètres de compression
- références spectrales (EQ adaptatif : le moteur corrige l'écart
  entre le spectre mesuré et la référence du profil)
- restrictions (vinyle : HPF, mono des graves)
"""

PROFILES = {
    "streaming": dict(
        id="streaming",
        name="Streaming",
        subtitle="Spotify · Apple Music · YouTube",
        description="Punch maîtrisé, compatible avec les plafonds de loudness des plateformes (-14 LUFS).",
        target_lufs=-14.0,
        ceiling=-1.0,
        comp=dict(ratio=2.5, offset=1.0, attack=0.018, release=0.22),
        min_crest=4.5,
        low_cut=30,
        mono_low=0,
        eq_max=3.0,
        # balance cible, en dB relatif à la bande mid (500 Hz–2 kHz)
        ref=dict(sub=-10.0, bass=-5.0, lowmid=-3.5, mid=0.0, highmid=-1.5, air=3.5),
    ),
    "radio": dict(
        id="radio",
        name="Radio / CD",
        subtitle="Diffusion · Broadcast · CD",
        description="Présence et clarté, compression légèrement plus marquée, transitoires protégées.",
        target_lufs=-16.0,
        ceiling=-1.0,
        comp=dict(ratio=3.0, offset=1.0, attack=0.015, release=0.28),
        min_crest=4.0,
        low_cut=35,
        mono_low=0,
        eq_max=3.0,
        ref=dict(sub=-11.0, bass=-5.5, lowmid=-4.0, mid=0.0, highmid=-1.0, air=4.0),
    ),
    "vinyl": dict(
        id="vinyl",
        name="Vinyle",
        subtitle="Pressage 33/45 tours",
        description="Graves restreints et mono sous 100 Hz, plafond plus bas pour préserver la dynamique du sillon.",
        target_lufs=-14.0,
        ceiling=-1.5,
        comp=dict(ratio=2.0, offset=2.0, attack=0.020, release=0.25),
        min_crest=5.0,
        low_cut=50,
        mono_low=100,
        eq_max=3.0,
        ref=dict(sub=-16.0, bass=-8.0, lowmid=-4.5, mid=0.0, highmid=-1.5, air=2.0),
    ),
    "club": dict(
        id="club",
        name="Club / EDM",
        subtitle="Soirées · Écoute mobile",
        description="Maximise la puissance : basses solides, hauts brillants, loudness élevée (-11 LUFS).",
        target_lufs=-11.0,
        ceiling=-0.8,
        comp=dict(ratio=3.2, offset=0.5, attack=0.012, release=0.15),
        min_crest=3.5,
        low_cut=25,
        mono_low=60,
        eq_max=3.0,
        ref=dict(sub=-8.0, bass=-4.0, lowmid=-4.0, mid=0.0, highmid=-1.0, air=4.0),
    ),
    "light": dict(
        id="light",
        name="Léger (naturel)",
        subtitle="Acoustique · Jazz · Pré-production",
        description="Toucher minimal : on ne compresse que si nécessaire, EQ subtil, plafond généreux.",
        target_lufs=-14.0,
        ceiling=-1.5,
        comp=dict(ratio=1.5, offset=3.0, attack=0.025, release=0.30),
        min_crest=8.0,
        low_cut=0,
        mono_low=0,
        eq_max=3.0,
        ref=dict(sub=-9.0, bass=-5.0, lowmid=-3.0, mid=0.0, highmid=-1.5, air=2.5),
    ),
}

BAND_LABEL = {
    "sub": "Sub-basses (20–60 Hz)",
    "bass": "Basses (60–250 Hz)",
    "lowmid": "Basses moyennes (250–500 Hz)",
    "mid": "Médiums (500 Hz–2 kHz)",
    "highmid": "Hautes (2–6 kHz)",
    "air": "Air (6–16 kHz)",
}

BAND_REASON = {
    "sub": ("renforcer le corps grave", "resserrer les sub-basses"),
    "bass": ("renforcer les basses", "alléger la section grave"),
    "lowmid": ("apporter de la clarté", "réduire la boue (250–500 Hz)"),
    "mid": ("donner de la rondeur", "dégager le centre du mix"),
    "highmid": ("ajouter de la présence", "adoucir la dureté"),
    "air": ("apporter de l'air", "réduire la brillance"),
}
