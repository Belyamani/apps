"""Studio Master IA — serveur web (aiohttp).

Lancement :  python3 server.py   →  http://localhost:8000
"""
import asyncio
import io
import json
import math
import re
import time
import uuid
from pathlib import Path

import numpy as np
import soundfile as sf
from aiohttp import web
from scipy.signal import resample_poly

from mastering import demo as demo_mod
from mastering.analysis import analyze_audio
from mastering.chain import run_chain
from mastering.profiles import PROFILES

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
OUT = Path("/tmp/master_out")

JOBS = {}
MAX_AGE = 1800  # 30 min
MAX_BYTES = 80 * 1024 * 1024
MAX_SECONDS = 3600


# ------------------------------------------------------------------ util
def _clean_jobs():
    now = time.time()
    for k in [k for k, v in JOBS.items() if now - v["created"] > MAX_AGE]:
        JOBS.pop(k, None)


def _store_job(x, sr, name):
    _clean_jobs()
    jid = uuid.uuid4().hex[:12]
    JOBS[jid] = dict(x=x, sr=sr, name=name, created=time.time())
    return jid


def _resample(x, sr):
    if sr == 44100:
        return x
    g = math.gcd(44100, int(sr))
    return resample_poly(x, 44100 // g, int(sr) // g, axis=0)


def _encode_mp3(x, sr, kbps=192):
    import lameenc
    pcm = np.clip(x * 32767.0, -32768, 32767).astype("<i2").tobytes()
    enc = lameenc.Encoder()
    enc.set_bit_rate(kbps)
    enc.set_in_sample_rate(sr)
    enc.set_channels(x.shape[1])
    enc.set_quality(5)
    return enc.encode(pcm) + enc.flush()


def _save_results(jid, sr, x, prof):
    d = OUT / jid
    d.mkdir(parents=True, exist_ok=True)
    sf.write(str(d / f"{prof}.wav"), x, sr, subtype="PCM_24")
    (d / f"{prof}.mp3").write_bytes(_encode_mp3(x, sr))


def _save_original(jid, sr, x):
    d = OUT / jid
    d.mkdir(parents=True, exist_ok=True)
    f = d / "original.wav"
    if not f.exists():
        sf.write(str(f), x, sr, subtype="PCM_16")
    return f


# ------------------------------------------------------------------ routes
async def h_index(request):
    return web.FileResponse(STATIC / "index.html")


async def h_analyze(request):
    reader = await request.multipart()
    field = await reader.next()
    if field is None:
        return web.json_response({"error": "Aucun fichier reçu."}, status=400)
    data = await field.read(decode=True)
    if not data:
        return web.json_response({"error": "Fichier vide."}, status=400)
    if len(data) > MAX_BYTES:
        return web.json_response({"error": "Fichier trop volumineux (max 80 Mo)."}, status=413)
    name = field.filename or "audio"

    def work():
        x, sr = sf.read(io.BytesIO(data), dtype="float64", always_2d=True)
        x = _resample(x, sr)
        if x.shape[0] > int(MAX_SECONDS * 44100 * 1.2):
            raise ValueError("Fichier trop long (max 1 h).")
        jid = _store_job(x, 44100, name)
        info = analyze_audio(x, 44100)
        return jid, info

    try:
        jid, info = await asyncio.to_thread(work)
    except ValueError as e:
        return web.json_response({"error": str(e)}, status=400)
    except Exception as e:  # noqa: BLE001
        return web.json_response(
            {"error": f"Lecture impossible : {e}. Formats acceptés : WAV, MP3, FLAC, OGG."},
            status=400,
        )
    return web.json_response({"job_id": jid, **info})


async def h_demo(request):
    def work():
        x, sr = demo_mod.make_demo()
        jid = _store_job(x, sr, "demo-ia.wav")
        info = analyze_audio(x, sr)
        return jid, info

    jid, info = await asyncio.to_thread(work)
    return web.json_response({"job_id": jid, **info})


async def h_master(request):
    form = await request.post()
    jid = form.get("job_id", "")
    prof = form.get("profile", "")
    job = JOBS.get(jid)
    if job is None:
        return web.json_response({"error": "Session expirée — réimportez le fichier."}, status=404)
    if prof not in PROFILES:
        return web.json_response({"error": "Profil inconnu."}, status=400)

    def work():
        x, sr = job["x"], job["sr"]
        before = analyze_audio(x, sr)
        out, steps = run_chain(x, sr, prof)
        after = analyze_audio(out, sr)
        _save_results(jid, sr, out, prof)
        _save_original(jid, sr, x)
        return before, after, steps

    before, after, steps = await asyncio.to_thread(work)
    return web.json_response({
        "before": before,
        "after": after,
        "steps": steps,
        "profile": prof,
        "files": {
            "wav": f"/api/result/{jid}/{prof}.wav",
            "mp3": f"/api/result/{jid}/{prof}.mp3",
            "original": f"/api/result/{jid}/original.wav",
        },
    })


async def h_result(request):
    jid = request.match_info["jid"]
    name = request.match_info["name"]
    if not re.fullmatch(r"[a-f0-9]{12}", jid) or not re.fullmatch(r"[\w.]+\.(wav|mp3)", name):
        return web.json_response({"error": "Chemin invalide."}, status=400)
    f = (OUT / jid / name).resolve()
    if OUT.resolve() not in f.parents or not f.is_file():
        return web.json_response({"error": "Fichier introuvable."}, status=404)
    # name a déjà été validé ([\w.]+\.(wav|mp3)) → sûr pour l'en-tête
    fr = web.FileResponse(
        f, headers={"Content-Disposition": 'attachment; filename="%s"' % name})
    return fr


async def h_profiles(request):
    return web.json_response(list(PROFILES.values()))


app = web.Application(client_max_size=MAX_BYTES + 1024 * 1024)
app.router.add_get("/", h_index)
app.router.add_static("/static", STATIC)
app.router.add_post("/api/analyze", h_analyze)
app.router.add_post("/api/demo", h_demo)
app.router.add_post("/api/master", h_master)
app.router.add_get("/api/profiles", h_profiles)
app.router.add_get("/api/result/{jid}/{name}", h_result)

if __name__ == "__main__":
    web.run_app(app, host="0.0.0.0", port=8000)
