/* Studio Master IA — interface */
"use strict";

const $ = (id) => document.getElementById(id);
const state = {
  jobId: null,
  info: null,
  profiles: [],
  profileId: null,
  result: null,
  fileName: null,
};

/* ------------------------------------------------------------- AB player */
class ABPlayer {
  constructor(onTick) {
    this.ctx = null;
    this.bufs = {};
    this.src = null;
    this.startedAt = 0;
    this.pos = 0;
    this.active = "a";
    this.onTick = onTick;
  }
  ensure() {
    if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (this.ctx.state === "suspended") this.ctx.resume();
    return this.ctx;
  }
  async load(url, key) {
    const r = await fetch(url);
    if (!r.ok) throw new Error("HTTP " + r.status);
    const ab = await r.arrayBuffer();
    this.bufs[key] = await this.ensure().decodeAudioData(ab);
    return this.bufs[key];
  }
  _stopSrc() {
    if (this.src) {
      try { this.src.onended = null; this.src.stop(); } catch (e) {}
      this.src.disconnect();
      this.src = null;
    }
  }
  play(key) {
    const ctx = this.ensure();
    const buf = this.bufs[key];
    if (!buf) return;
    this._stopSrc();
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = 1;
    src.connect(g).connect(ctx.destination);
    const offset = Math.min(this.pos, Math.max(0, buf.duration - 0.05));
    src.start(0, offset);
    this.src = src;
    this.startedAt = ctx.currentTime - offset;
    this.active = key;
    src.onended = () => {
      if (this.src === src) {
        this._stopSrc();
        this.pos = 0;
        this.onTick(0, true);
      }
    };
  }
  pause() {
    if (!this.src) return;
    this.pos = this.ctx.currentTime - this.startedAt;
    this._stopSrc();
    this.onTick(this.pos, false);
  }
  toggle() { this.src ? this.pause() : this.play(this.active); }
  set(key) {
    const playing = !!this.src;
    const pos = this.src ? this.ctx.currentTime - this.startedAt : this.pos;
    this._stopSrc();
    this.pos = pos;
    this.active = key;
    if (playing) this.play(key);
  }
  now() { return this.src ? this.ctx.currentTime - this.startedAt : this.pos; }
  stop() { this._stopSrc(); this.pos = 0; this.onTick(0, false); }
}

/* ------------------------------------------------------------- helpers */
const fmtTime = (s) => {
  s = Math.max(0, Math.floor(s));
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
};
const fmtDur = (s) =>
  s >= 60 ? Math.floor(s / 60) + " min " + Math.round(s % 60) + " s" : s.toFixed(1) + " s";

function show(id) { $(id).classList.remove("hidden"); }
function hide(id) { $(id).classList.add("hidden"); }

/* ------------------------------------------------------------- upload */
const dz = $("dropzone");
const fileInput = $("file");

$("btn-browse").addEventListener("click", (e) => { e.stopPropagation(); fileInput.click(); });
dz.addEventListener("click", () => fileInput.click());
$("btn-demo").addEventListener("click", (e) => { e.stopPropagation(); loadDemo(); });
fileInput.addEventListener("change", () => fileInput.files[0] && upload(fileInput.files[0]));

["dragover", "dragenter"].forEach((ev) =>
  dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("drag"); }));
["dragleave", "drop"].forEach((ev) =>
  dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("drag"); }));
dz.addEventListener("drop", (e) => e.dataTransfer.files[0] && upload(e.dataTransfer.files[0]));

function setBusy(label) {
  $("btn-master").disabled = true;
  $("btn-demo").disabled = true;
  dz.style.opacity = label ? ".5" : "1";
}

async function upload(file) {
  hide("upload-error");
  setBusy(true);
  dz.querySelector(".dz-inner").querySelector("p").innerHTML =
    "⏳ Analyse de <strong>" + file.name + "</strong>…";
  try {
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch("/api/analyze", { method: "POST", body: fd });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "Erreur inconnue");
    state.jobId = j.job_id;
    state.info = j;
    state.fileName = file.name;
    onAnalyzed();
  } catch (e) {
    $("upload-error").textContent = "⚠️ " + e.message;
    show("upload-error");
  } finally {
    setBusy(false);
    dz.querySelector(".dz-inner").querySelector("p").innerHTML =
      "<strong>Glissez-déposez</strong> votre audio ici<br><small>WAV · MP3 · FLAC · OGG — max 80 Mo, 1 h</small>";
  }
}

async function loadDemo() {
  hide("upload-error");
  setBusy(true);
  dz.querySelector(".dz-inner").querySelector("p").innerHTML = "⏳ Génération de la démo…";
  try {
    const r = await fetch("/api/demo", { method: "POST" });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "Erreur inconnue");
    state.jobId = j.job_id;
    state.info = j;
    state.fileName = "démo Studio Master IA";
    onAnalyzed();
  } catch (e) {
    $("upload-error").textContent = "⚠️ " + e.message;
    show("upload-error");
  } finally {
    setBusy(false);
    dz.querySelector(".dz-inner").querySelector("p").innerHTML =
      "<strong>Glissez-déposez</strong> votre audio ici<br><small>WAV · MP3 · FLAC · OGG — max 80 Mo, 1 h</small>";
  }
}

/* ------------------------------------------------------------- analyse */
function onAnalyzed() {
  const i = state.info;
  $("file-info").innerHTML =
    "📄 <strong>" + state.fileName + "</strong> — " + fmtDur(i.duration_s) +
    " · " + i.sample_rate + " Hz · " + (i.channels === 1 ? "mono" : "stéréo");
  show("file-info");

  const m = $("metrics");
  const cards = [
    ["Loudness", i.lufs, "LUFS", "cible profil : -14 à -11"],
    ["Pic", i.peak_db, "dB", "idéal < -1 dB"],
    ["RMS", i.rms_db, "dB", "niveau moyen"],
    ["Dynamique", i.dynamic_range, "dB", "écart loudness 1 s (p5–p95)"],
    ["Crête", i.crest, "dB", "pic − loudness"],
    ["Stéréo", i.width, "%", i.channels === 1 ? "signal mono" : "largeur"],
  ];
  m.innerHTML = cards
    .map(([k, v, u, h]) =>
      '<div class="metric"><div class="v">' + v + '<small> ' + u + "</small></div>" +
      '<div class="k">' + k + "</div><div class=\"hint\">" + h + "</div></div>")
    .join("");
  show("analysis-card");
  drawSpectrum(i.curve);

  const w = $("warnings");
  w.innerHTML =
    (i.clipping ? "<div>⚠️ Signes de clipping détectés — le limiteur les corrigera.</div>" : "") +
    (i.dc ? "<div>⚠️ Dérive DC détectée — elle sera supprimée.</div>" : "");
  w.innerHTML = w.innerHTML.trim();

  renderProfiles();
  show("profile-card");
  $("profile-card").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function drawSpectrum(curve) {
  const c = $("spectrum");
  const ctx = c.getContext("2d");
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  const pad = { l: 8, r: 8, t: 10, b: 22 };
  const minDb = -40;
  const X = (i) => pad.l + (i / (curve.length - 1)) * (W - pad.l - pad.r);
  const Y = (db) =>
    pad.t + (1 - Math.max(0, Math.min(1, (db - minDb) / (0 - minDb)))) * (H - pad.t - pad.b);
  // grille
  ctx.strokeStyle = "#1d2536";
  ctx.lineWidth = 1;
  for (const db of [-10, -20, -30]) {
    ctx.beginPath(); ctx.moveTo(pad.l, Y(db)); ctx.lineTo(W - pad.r, Y(db)); ctx.stroke();
  }
  // aire
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, "rgba(124,108,255,.55)");
  grad.addColorStop(1, "rgba(57,208,255,.08)");
  ctx.beginPath();
  ctx.moveTo(X(0), Y(curve[0]));
  curve.forEach((v, i) => ctx.lineTo(X(i), Y(v)));
  ctx.lineTo(X(curve.length - 1), H - pad.b);
  ctx.lineTo(X(0), H - pad.b);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.strokeStyle = "#8f7fff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  curve.forEach((v, i) => (i ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v))));
  ctx.stroke();
  // axe
  ctx.fillStyle = "#8b96ad";
  ctx.font = "11px sans-serif";
  for (const [i, lab] of [["30 Hz", 0], ["100 Hz", 4], ["1 kHz", 12], ["10 kHz", 27], ["16 kHz", 39]])
    ctx.fillText(lab, X(i) - 14, H - 6);
}

/* ------------------------------------------------------------- profils */
function recommend(info) {
  if (info.lufs > -9) return "radio";
  if (info.crest < 4) return "club";
  return "streaming";
}

async function renderProfiles() {
  if (!state.profiles.length) {
    const r = await fetch("/api/profiles");
    state.profiles = await r.json();
  }
  const rec = recommend(state.info);
  $("profiles").innerHTML = state.profiles
    .map(
      (p) =>
        '<div class="profile" data-id="' + p.id + '">' +
        (p.id === rec ? '<span class="badge">RECOMMANDÉ</span>' : "") +
        '<div class="nm">' + p.name + "</div>" +
        '<div class="sb">' + p.subtitle + "</div>" +
        '<div class="ds">' + p.description + "</div>" +
        '<div class="chips"><span class="chip">' + p.target_lufs.toFixed(0) +
        ' LUFS</span><span class="chip">plafond ' + p.ceiling.toFixed(1) + ' dB</span></div>' +
        "</div>"
    )
    .join("");
  document.querySelectorAll(".profile").forEach((el) =>
    el.addEventListener("click", () => selectProfile(el.dataset.id)));
  selectProfile(rec);
}

function selectProfile(id) {
  state.profileId = id;
  document.querySelectorAll(".profile").forEach((el) =>
    el.classList.toggle("selected", el.dataset.id === id));
  $("btn-master").disabled = false;
}

/* ------------------------------------------------------------- mastering */
$("btn-master").addEventListener("click", async () => {
  if (!state.jobId || !state.profileId) return;
  hide("result-card");
  show("progress-card");
  $("progress-card").scrollIntoView({ behavior: "smooth", block: "nearest" });

  const stages = [
    "Analyse du spectre et de la dynamique…",
    "Calcul de l'EQ adaptatif…",
    "Compression et contrôle du niveau…",
    "Ajustement vers la cible LUFS…",
    "Limiteur et encodage des fichiers…",
  ];
  const list = $("progress-steps");
  list.innerHTML = stages.map((s) => "<li>" + s + "</li>").join("");
  const lis = list.querySelectorAll("li");
  let i = 0;
  function markProgress() {
    lis.forEach((li, idx) => {
      li.classList.toggle("on", idx === i);
      li.classList.toggle("done", idx < i);
      const s = li.querySelector(".spin");
      if (idx === i) {
        if (!s) {
          const sp = document.createElement("span");
          sp.className = "spin";
          li.prepend(sp);
        }
      } else if (s) s.remove();
    });
    if (i < lis.length) i++;
  }
  markProgress();
  const iv = setInterval(markProgress, 1600);

  try {
    const fd = new FormData();
    fd.append("job_id", state.jobId);
    fd.append("profile", state.profileId);
    const r = await fetch("/api/master", { method: "POST", body: fd });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "Erreur inconnue");
    clearInterval(iv);
    hide("progress-card");
    state.result = j;
    renderResult(j);
  } catch (e) {
    clearInterval(iv);
    hide("progress-card");
    $("upload-error").textContent = "⚠️ " + e.message;
    show("upload-error");
  }
});

/* ------------------------------------------------------------- résultat */
const METRIC_ROWS = [
  ["Loudness (LUFS)", "lufs", "dB", +1],
  ["Pic (dB)", "peak_db", "dB", -1],
  ["RMS (dB)", "rms_db", "dB", 0],
  ["Dynamique (dB)", "dynamic_range", "dB", 0],
  ["Crête (dB)", "crest", "dB", 0],
];

function renderResult(j) {
  const prof = state.profiles.find((p) => p.id === j.profile);
  $("result-profile-name").textContent = "— profil " + (prof ? prof.name : j.profile);

  const rows = METRIC_ROWS.map(([label, k, u, goodDir]) => {
    const b = j.before[k], a = j.after[k];
    const d = a - b;
    const cls = Math.abs(d) < 0.05 ? "" : d > 0 ? (goodDir >= 0 ? "up" : "dn") : (goodDir <= 0 ? "up" : "dn");
    const arrow = d > 0.05 ? "▲" : d < -0.05 ? "▼" : "•";
    return "<tr><td>" + label + "</td><td>" + b + " " + u + "</td><td><strong>" + a +
      " " + u + "</strong><span class=\"delta " + cls + "\">" + arrow + " " +
      (d > 0 ? "+" : "") + d.toFixed(1) + "</span></td></tr>";
  }).join("");
  $("ab-table").innerHTML =
    "<tr><th>Mesure</th><th>Avant</th><th>Après</th></tr>" + rows;

  $("steps-report").innerHTML = j.steps.map((s) => "<li>" + s + "</li>").join("");

  $("dl-wav").href = j.files.wav;
  $("dl-mp3").href = j.files.mp3;
  const base = "master-" + j.profile;
  const openLink = $("dl-open");
  openLink.classList.add("hidden");
  function revealOpen(url) {
    openLink.href = url;
    openLink.target = "_blank";
    openLink.classList.remove("hidden");
  }
  const wire = (btn, url, name) => {
    btn.onclick = (e) => {
      e.preventDefault();
      doDownload(url, name).catch((err) =>
        alert("⚠️ " + err.message + "\n\nVous pouvez relancer la masterisation pour régénérer les fichiers."));
      // filet : si le téléchargement est bloqué par la fenêtre, un lien de secours apparaît
      setTimeout(() => revealOpen(url), 1200);
    };
  };
  wire($("dl-wav"), j.files.wav, base + ".wav");
  wire($("dl-mp3"), j.files.mp3, base + ".mp3");
  show("result-card");
  $("result-card").scrollIntoView({ behavior: "smooth", block: "start" });

  // joueur A/B + forme d'onde
  const p = player;
  p.stop();
  (async () => {
    try {
      const [ba, bb] = await Promise.all([
        p.load(j.files.original, "a"),
        p.load(j.files.wav, "b"),
      ]);
      waveBufs = { a: ba, b: bb };
      drawWave(0);
      $("btn-play").textContent = "▶";
    } catch (e) {
      // repli : lecture directe du fichier masterisé
      waveBufs = {};
      p.bufs["b"] = await (async () => {
        const r = await fetch(j.files.mp3);
        return p.ensure().decodeAudioData(await r.arrayBuffer());
      })();
      drawWave(0);
    }
  })();
}

/* ------------------------------------------------------------- téléchargement */
async function doDownload(url, name) {
  const r = await fetch(url);
  if (!r.ok) {
    const j = {};
    try { Object.assign(j, await r.json()); } catch (e) {}
    throw new Error(j.error || ("HTTP " + r.status));
  }
  const blob = await r.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10000);
}

/* ------------------------------------------------------------- onde */
let waveBufs = {};

function peaks(buffer, width) {
  const data = buffer.getChannelData(0);
  const step = Math.max(1, Math.floor(data.length / width));
  const out = new Float32Array(width * 2);
  for (let x = 0; x < width; x++) {
    let mn = 1, mx = -1;
    const end = Math.min(data.length, (x + 1) * step);
    for (let i = x * step; i < end; i += Math.max(1, Math.floor(step / 50))) {
      const v = data[i];
      if (v < mn) mn = v;
      if (v > mx) mx = v;
    }
    out[x * 2] = mn;
    out[x * 2 + 1] = mx;
  }
  return out;
}

function drawWave(pos) {
  const c = $("wave");
  const ctx = c.getContext("2d");
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = "#0d1119";
  ctx.fillRect(0, 0, W, H);
  const mid = H / 2;
  for (const [key, color, alpha] of [["a", "#5a6478", 0.9], ["b", "#39d0ff", 0.95]]) {
    const buf = waveBufs[key];
    if (!buf) continue;
    const pk = peaks(buf, W);
    ctx.strokeStyle = color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = key === "b" ? 1.4 : 1;
    for (let x = 0; x < W; x++) {
      const mn = pk[x * 2], mx = pk[x * 2 + 1];
      ctx.beginPath();
      ctx.moveTo(x + 0.5, mid + mn * (H / 2 - 4));
      ctx.lineTo(x + 0.5, mid + mx * (H / 2 - 4));
      ctx.stroke();
    }
  }
  ctx.globalAlpha = 1;
  // tête de lecture
  const bufA = waveBufs.a || waveBufs.b;
  if (bufA) {
    const x = Math.min(1, pos / bufA.duration) * W;
    ctx.strokeStyle = "#e8ecf4";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
}

/* ------------------------------------------------------------- player UI */
const player = new ABPlayer((pos, ended) => {
  const buf = waveBufs.a || waveBufs.b;
  $("time").textContent = fmtTime(pos) + " / " + (buf ? fmtTime(buf.duration) : "–");
  if (ended) $("btn-play").textContent = "▶";
});

let raf = null;
function tick() {
  if (player.src) {
    const p = player.now();
    drawWave(p);
    const buf = waveBufs.a || waveBufs.b;
    $("time").textContent = fmtTime(p) + " / " + (buf ? fmtTime(buf.duration) : "–");
    raf = requestAnimationFrame(tick);
  }
}
function playheadSync() {
  cancelAnimationFrame(raf);
  if (player.src) raf = requestAnimationFrame(tick);
}

$("btn-play").addEventListener("click", () => {
  if (!waveBufs.a && !waveBufs.b) return;
  if (!player.src && !player.pos) player.pos = 0;
  player.toggle();
  $("btn-play").textContent = player.src ? "⏸" : "▶";
  playheadSync();
});

function setAB(key) {
  $("ab-a").classList.toggle("active", key === "a");
  $("ab-b").classList.toggle("active", key === "b");
  player.set(key);
  playheadSync();
  $("btn-play").textContent = player.src ? "⏸" : "▶";
}
$("ab-a").addEventListener("click", () => setAB("a"));
$("ab-b").addEventListener("click", () => setAB("b"));
