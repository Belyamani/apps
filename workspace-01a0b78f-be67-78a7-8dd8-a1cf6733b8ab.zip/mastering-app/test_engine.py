"""Test end-to-end du moteur : démo → analyse → mastering (tous profils)."""
import sys
import time

import numpy as np

sys.path.insert(0, ".")
from mastering.demo import make_demo
from mastering.analysis import analyze_audio
from mastering.chain import run_chain
from mastering.profiles import PROFILES

print("== Génération démo ==")
t0 = time.time()
x, sr = make_demo()
print(f"démo : {x.shape}, {sr} Hz, {time.time()-t0:.1f} s")

t0 = time.time()
info = analyze_audio(x, sr)
print(f"== Analyse ({time.time()-t0:.1f} s) ==")
for k, v in info.items():
    if k != "curve":
        print(f"  {k}: {v}")
print("  curve[:8]:", info["curve"][:8])

fail = 0
for pid in PROFILES:
    t0 = time.time()
    out, steps = run_chain(x, sr, pid)
    after = analyze_audio(out, sr)
    dt = time.time() - t0
    # Invariants du moteur :
    #  - le pic ne dépasse jamais le plafond (sécurité, +0.5 de tolérance),
    #  - le signal reste fini,
    #  - le mastering n'abaisse pas la loudness (il la fait monter),
    #  - la loudness approche la cible ; l'écart possible vient du plafond
    #    des pics (matériau trop crêteux), toujours signalé dans les étapes.
    ok_peak = after["peak_db"] <= PROFILES[pid]["ceiling"] + 0.5
    ok_lufs = (after["lufs"] >= PROFILES[pid]["target_lufs"] - 6.0
               and after["lufs"] <= PROFILES[pid]["target_lufs"] + 1.5)
    ok_fin = bool(np.isfinite(out).all())
    ok_louder = after["lufs"] >= info["lufs"] + 2.0
    if not (ok_peak and ok_lufs and ok_fin and ok_louder):
        fail += 1
    print(f"\n== Profil {pid} ({dt:.1f} s) ==")
    print(f"  LUFS {info['lufs']} → {after['lufs']} (cible {PROFILES[pid]['target_lufs']})  "
          f"{'OK' if ok_lufs else 'ECART'}   plus fort: {'OK' if ok_louder else 'NON'}")
    print(f"  pic  {info['peak_db']} → {after['peak_db']} (plafond {PROFILES[pid]['ceiling']})  "
          f"{'OK' if ok_peak else 'DEPASSE'}   fini: {'OK' if ok_fin else 'NON'}")
    for s in steps:
        print("   ·", s)

print("\n" + ("TOUS LES TESTS PASSENT ✓" if fail == 0 else f"{fail} PROFIL(S) EN ECART"))
